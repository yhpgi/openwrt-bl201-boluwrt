.. cmake-module:: ../../Modules/FindGIF.cmake
